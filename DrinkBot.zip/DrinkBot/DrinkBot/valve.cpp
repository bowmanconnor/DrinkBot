#include "valve.h"

Valve::Valve(Servo* _servoPtr, int servoPin, int _openAngle, int _closedAngle){
  servoPtr = _servoPtr;
  openAngle = _openAngle;
  closedAngle = _closedAngle;

  servoPtr->attach(servoPin);
}

void Valve::setOpenAngle(int _openAngle){
  openAngle = _openAngle;
}

void Valve::setClosedAngle(int _closedAngle){
  closedAngle = _closedAngle;
}

bool Valve::isOpen(){
  return currentState;
}

void Valve::open(){
  servoPtr->write(openAngle);
}

void Valve::close(){
  servoPtr->write(closedAngle);
}
