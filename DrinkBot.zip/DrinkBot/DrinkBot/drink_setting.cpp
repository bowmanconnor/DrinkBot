#include "drink_setting.h"
#include "String.h"

DrinkSetting::DrinkSetting(float valveOneOpenTime, float valveTwoOpenTime, char *lineOneString, char *lineTwoString){
  this->valveOneOpenTime = valveOneOpenTime;
  this->valveTwoOpenTime = valveTwoOpenTime;
  strcpy(this->lineOneString, lineOneString);
  strcpy(this->lineTwoString, lineTwoString);
}
