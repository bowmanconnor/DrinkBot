#ifndef DRINK_SETTING_H
#define DRINK_SETTING_H

class DrinkSetting{
  public:
    float valveOneOpenTime, valveTwoOpenTime;
    char lineOneString[15];
    char lineTwoString[15];
    DrinkSetting(float, float, char*, char*);
};

#endif
