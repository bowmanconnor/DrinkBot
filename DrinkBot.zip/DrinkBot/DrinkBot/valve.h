#ifndef VALVE_H
#define VALVE_H
#include <ESP32_Servo.h>

class Valve{
  private:
    int openAngle, closedAngle;
    bool currentState;
    Servo* servoPtr;
  public:
    void setOpenAngle(int);
    void setClosedAngle(int);
    bool isOpen();
    void open();
    void close();
    Valve(Servo*, int, int, int);
};

#endif
