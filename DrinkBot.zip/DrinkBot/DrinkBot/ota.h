#include <Update.h>
#include <WiFi.h>

#define OTA_HOST "cjelm.spdns.org"
#define OTA_PORT 1234
#define FIRMWARE_BIN "/firmware.bin"
// This would get the file from http://cjelm.spdns.org:1234/firmware.bin

void perform_ota(WiFiClient* client);
